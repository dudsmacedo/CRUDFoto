﻿using Microsoft.EntityFrameworkCore;
using TrabalhoFotoIgor.Models;

namespace TrabalhoFotoIgor.Context
{
    public class AppCont : DbContext
    {
        public AppCont(DbContextOptions<AppCont> options) : base(options)
        {

        }

        public DbSet<Cad_cliente> Clientes { get; set; }
    }
}
